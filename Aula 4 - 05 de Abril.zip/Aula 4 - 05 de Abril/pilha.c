#include <stdio.h>
#include <stdlib.h>
#define MAX 5

typedef	struct _pilha{
	int info[MAX];
	int topo;
}tp_pilha;

void iniciar(struct tp_pilha *p){
	p-> topo = -1; //inicia a pilha
}

int espaco_vazio(struct tp_pilha *p){//verifica se a pilha está vazia ou cheia
	if(p->topo == -1){
		printf("Sua pilha esta vazia\n");
		return 1;
	}else
		return 0;
}

int espaco_cheio(struct tp_pilha *p){//verifica se a cheia
	if(p->topo == (MAX - 1)){
		printf("\nSua pilha esta cheia\n");
		return 1;
	}else
		return 0;
}

int push(struct tp_pilha *p, int valor){ //insere elementos na pilha
	return (p->info[++(p->topo)] = valor);
}

int pop(struct tp_pilha p){//remove intem da pilha
	int aux;
	aux = p->intem[(p->topo)--];
	return aux;
}
int display(struct tp_pilha *p){ //mostra os valores
	int aux;
	if(vazia (p))
		return 1;
	else{
		aux = pop (p);
		printf("%d,", aux);
		display(p);
		return 0;
	}
}	
int inserir(struct tp_pilha *p){//insere registro
	int op;
	printf("Informe um valor para ser empilhado ou zero para sair:");
	scanf("%d", &op);
	if(espaco_cheio(p))
		return 1;
	else{
		if(valor == -1){
			return 0;
		}else{
			push (p, valor);
			inserir(p);
			return 0;
		}
	}
}
int main(){
int op, *p;
	
	struct tp_pilha;

	printf("Pilhas:\n");
	printf("\t1 - Inserir\n");
	printf("\t2 - Remover\n");
	printf("\t3 - Listar\n");
	printf("\t4 - Sair\n");
	printf("\tSelecao: ");
	scanf("%d", &op);
	do{
		if(op==1){
			iniciar(&pilha);
			inserir(&);
		}
		else if(op==2){
			pop(&pilha);
		}
		else if(op == 3){
			mostra(&pilha);
		}
		else if(op==4){
			printf("Saindo........\n");
			printf("Volte logo\n");		
		}
	}while(op<=3);
return 0;
}