#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdio_ext.h>
#define TAM 50

typedef struct _produto{
	int cod;
	char nome[TAM];
	float preco;
}tp_produto;

typedef struct _pilha{
	tp_produto *info;
	int topo;
}tp_pilha;

tp_pilha* inicia_pilha_vazia(tp_pilha *p_pilha){
	
	p_pilha = (tp_pilha *)malloc(sizeof(tp_pilha));
	p_pilha->topo = -1;
	return p_pilha;
}

void espaco_produtos(tp_pilha *p_pilha, int n){//Alocar produtos
	
	tp_produto *p_produto;
	tp_pilha *p_new;
	p_pilha->info = (tp_produto *)malloc(sizeof(tp_produto)*n);
}

void push(tp_pilha *p_pilha, int n){
	if(p_pilha->topo == n-1){//verifica se pilha esta cheia
		system("clear");
		printf("ATENCAO: Pilha Cheia.\n");
		printf("Exclua algo para continuar.\n");
		printf("Voltando para o menu..............\n\n");
	}else{
		p_pilha->topo++; //se com espaco, insere produto
		printf("Inserir Produtos\n\n");
		getchar();
		printf("Nome: ");
		fgets((p_pilha->info + p_pilha->topo)->nome,TAM,stdin);
		printf("Codigo: ");
		scanf("%d", &(p_pilha->info + p_pilha->topo)->cod);
		printf("Preco: ");
		scanf("%f", &(p_pilha->info + p_pilha->topo)->preco);
		system("clear ");
	}
}

void pop(tp_pilha *p_pilha, int n){
	if(p_pilha->topo == -1){ //verifica se esta vazia
		printf("ATENCAO: Pilha esta vazia\n");
		printf("Voltando para o menu..............\n\n");
	}else{
		p_pilha->topo--;
	}
}

void display(tp_pilha *p_pilha, int n){
int i;
	printf("Lista de Produtos\n\n");
	for(i = 0; i <= p_pilha->topo; i++){
		printf("Nome: %s", (p_pilha->info + i)->nome);
		printf("Codigo: %d\n", (p_pilha->info + i)->cod);
		printf("Preco: R$%.2f\n\n", (p_pilha->info + i)->preco);
	}
printf("\n");
}

void free_all(tp_pilha *p_pilha){
	free(p_pilha->info);
	free(p_pilha);
}


int main(){
	
	tp_pilha *p_pilha;
	int qtd_produtos, op;
	
	p_pilha = inicia_pilha_vazia(p_pilha);

	printf("Digite quantidade de produtos para o cadastro: ");
	scanf("%d", &qtd_produtos);
	system("clear");
	getchar();

	espaco_produtos(p_pilha, qtd_produtos);    
    
do{
    printf("MENU PRODUTOS\n");
	printf("1 - Inserir Produtos\n");
	printf("2 - Excluir Produtos\n");
	printf("3 - Listar Produtos\n");
	printf("0 - Sair\n");
	printf("Selecione: ");
	scanf("%d", &op);
	system("clear");
switch(op){
	case 1: 
		push(p_pilha, qtd_produtos);
    break;
   
	case 2: 
    	pop(p_pilha, qtd_produtos);
    break;    
	case 3:
        display(p_pilha, qtd_produtos);
    break;	
	}
}while(op != 0);
return 0; 
}