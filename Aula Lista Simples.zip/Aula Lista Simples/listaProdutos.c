#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdio_ext.h>
#define TAM 100

typedef struct produto{
	int codigo;
	char nome[TAM];
	float preco;
}tp_produto;		

typedef struct nodo{
	tp_produto produto;
	struct nodo *prox;
}tp_nodo;

tp_nodo *inserir(tp_nodo *p){ //insere elementos na lista
	//variavel p aponta para o tp nodo
	tp_nodo *N = (tp_nodo *)malloc(sizeof(tp_nodo));
	printf("Cadastro do Produto\n");
	printf("Codigo: ");
	scanf("%d", &(N->produto.codigo));		
	printf("Nome: ");
	scanf("%s", (N->produto.nome));
	printf("Preco: ");
	scanf("%f", &(N->produto.preco));
	N->prox = p;
	system("clear");
	return N;
}

tp_nodo*  excluir(tp_nodo *p, int codigo){
tp_nodo* atual = p;
tp_nodo* anter = NULL; //variavel que recebe a lista	
	if(atual == NULL){//verificar se a lista ta vazia se estiver vai parar 
		printf("A lista esta vazia\n");
		printf("Voltando ao menu inicial.............\n");
	return NULL;
	}
	if(atual->produto.codigo == codigo){ //se a variavel atual for igual codigo do produto
		p = atual->prox;
		free(atual); 
		return p;
	}
	while(atual != NULL){
		if(atual->produto.codigo == codigo){  //se tem produtos com o mesmo codigo
			tp_nodo* RemoverProduto = atual;	
			anter->prox = atual->prox;
			free(RemoverProduto);
			break;
		}
		anter = atual;
		atual = atual->prox;
	}
	return p;
}

void display(tp_nodo *p){ //percorre a lista e da print na tela os produtos 
	tp_nodo *i;
	printf("Lista de Produtos\n");
	for(i = p; i != NULL ; i = i -> prox){
		printf("Codigo: %d\n", i->produto.codigo);
		printf("Nome: %s\n", i->produto.nome);
		printf("Preco: %.2f\n", i->produto.preco);
		printf("\n");
	}	
}

int main(){

	int op, codigo;
	
	tp_nodo *p = NULL;

do{	
	printf("MENU PRINCIPAL\n");
	printf("1 - Inserir Produto\n");
	printf("2 - Excluir Produto\n");
	printf("3 - Listar Produtos\n");
	printf("0 - Sair\n");
	printf("Selecione: ");
	scanf("%d", &op);
	system("clear");	
	
	switch(op){
	case 1:
		p = inserir(p);
	break;
	case 2:
		printf("Digite o codigo do produto para remocao: ");
		scanf("%d", &codigo);
		p = excluir(p, codigo);
	break;
	case 3:
		display(p);
	break;
	}
}while(op != 0);	

return 0; 
}