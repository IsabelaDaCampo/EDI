#include <stdio.h>
void swap(int *a, int *b){
	int troca;
	
	printf("\nValores invertidos:\n");
	troca = *a;

	*a = *b;
	*b = troca;

	printf("v1 = %d\n", *a);
	printf("v2 = %d\n", *b);
}
int main (){
	int v1 = 10, v2 = 20;

	printf("Valores originais:\n");
	printf("v1 = %d\n", v1);
	printf("v2 = %d", v2);

	swap(&v1, &v2);
return 0;
}