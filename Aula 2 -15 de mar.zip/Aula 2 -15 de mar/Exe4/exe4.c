#include <stdio.h>
void calcula_quadrado(int lado, float *area, float *perimetro){
	*area = lado * lado;
	*perimetro = lado * 4;

}
int main (){
	float area = 0, perimetro = 0;
	int lado;

	printf("Informe o tamanho do lado:");
	scanf("%d", &lado);

	calcula_quadrado(lado, &area, &perimetro);

	printf("Valor da area: %f\n", area);
	printf("Valor do perimetro %f\n", perimetro);
return 0;
}