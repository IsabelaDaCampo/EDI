#include <stdio.h>
void imprime (char *v, int n){
	char *c;
	for (c = v; c < v + n; v++){
		printf("Teste -- %c ", *c);
	}
	printf("Se -1 nao imprime nada\n");
}
int main (){

	char a = 'a';
	int n = 2;

	imprime(&a, n);
return 0;
}