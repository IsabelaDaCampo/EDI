#include <stdio.h>
int main (){
	int valor1, valor2;
	int *p1, *p2;

	p1 = &valor1;
	p2 = &valor2;
	
	*p1 = 10;
	*p2 = *p1;

	p1 = p2;
	*p1 = 20;

	printf("Valor 1 = %d\n", valor1);
	printf("Valor 2 = %d\n", valor2);

return 0;
}