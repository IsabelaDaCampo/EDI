#include <stdio.h>
int main (){
	int v1 = 10;
	float v2 = 2.50;

	void *p;

	p = &v1;
	printf("%d\n", *(int *)p);

	p = &v2;
	printf("%0.2f\n", *(float *)p);

return 0;
}